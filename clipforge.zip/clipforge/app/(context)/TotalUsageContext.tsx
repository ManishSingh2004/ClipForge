import { createContext } from "react";

export const TotalUsageContext=createContext<any>(0);